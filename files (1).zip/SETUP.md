# Streaks v2 — Setup & Deployment Guide

## Step 1: Create Firebase Project (5 min)

1. Go to https://console.firebase.google.com
2. Click **"Add project"** → name it `streaks-habit-app` → Continue
3. Disable Google Analytics (optional) → **Create project**

## Step 2: Enable Authentication

1. In Firebase Console → **Authentication** → **Get started**
2. Click **Sign-in method** tab
3. Enable **Email/Password** → Save
4. Enable **Google** → add your support email → Save

## Step 3: Enable Firestore Database

1. Firebase Console → **Firestore Database** → **Create database**
2. Choose **"Start in test mode"** → Next → Select your region → Done

## Step 4: Get Your Config

1. Firebase Console → ⚙️ Project Settings → **Your apps**
2. Click **"</>"** (Web) → Register app as `streaks-web` → Continue
3. Copy the `firebaseConfig` object shown

## Step 5: Paste Config into index.html

Open `index.html` and find this block near the top:

```js
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

Replace it with the config you copied from Firebase.

## Step 6: Set Firestore Security Rules

In Firebase Console → Firestore → **Rules**, replace with:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Click **Publish**.

## Step 7: Deploy to Vercel (Free)

1. Upload all 3 files to a new GitHub repo
2. Go to https://vercel.com → Import project → select your repo
3. Click **Deploy** — done!

Your app is live at `https://your-repo-name.vercel.app`

## Step 8: Install as PWA on Phone

- **Android (Chrome)**: tap ⋮ menu → "Add to Home screen"
- **iPhone (Safari)**: tap Share → "Add to Home Screen"

---

## Firestore Data Structure

```
users/
  {uid}/
    habitLimit: 10
    habits/
      {habitId}/
        name, icon, color, time, createdAt
    completions/
      {habitId_YYYY-MM-DD}/
        habitId, date, count, ts
    devices/
      {deviceId}/
        name, lastSeen, userAgent
```

---

## Files in this package

| File | Purpose |
|------|---------|
| `index.html` | Full PWA app (all screens, auth, sync, PDF) |
| `sw.js` | Service worker (offline support) |
| `manifest.json` | PWA metadata (install on home screen) |
| `SETUP.md` | This guide |
